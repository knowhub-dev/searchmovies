<?php
const DB_HOST = '127.0.0.1';
const DB_NAME = 'searchmoviess';
const DB_USER = 'root';
const DB_PASS = 'password';

const APP_URL = 'https://searchmoviess.uz';
const APP_NAME = 'SearchMoviess';
const SESSION_COOKIE = 'smv2';
const SESSION_LIFETIME = 60*60*24*7;
